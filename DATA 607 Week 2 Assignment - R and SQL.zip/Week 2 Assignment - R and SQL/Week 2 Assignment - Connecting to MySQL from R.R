# Week 2 Assignment - R and SQL
# Student: Kalyan (Kalyanaraman Parthasarathy)

# Clear the console
cat("\014")

# Read the DB password for "ruser" from the file
password = read.table("/Users/vidyakalyan/Data/ruser-password.txt")

# Install and Load RMySQL package that helps to connect to MySQL DB
# install.packages("RMySQL")
library(RMySQL)

# Connect to MySQL DB
mySQLConnection = dbConnect(MySQL(), user='ruser', password=toString(password[1,1]), dbname='entertainment', host='localhost')

# Just for verification - List the tables in the DB
dbListTables(mySQLConnection)

# Get the records from the "movies" table
moviesResultset = dbSendQuery(mySQLConnection, 'select * from movies order by movie_name')

# Reads the results as Dataframe
moviesResultsAsDataframe = fetch(moviesResultset, n=-1)

# Display the query results
moviesResultsAsDataframe

# Get the records from the "ratings" table
ratingsResultset = dbSendQuery(mySQLConnection, 'select * from ratings order by movie_name')

# Reads the results as Dataframe
ratingsResultsAsDataframe = fetch(ratingsResultset, n=-1)

# Display the query results
ratingsResultsAsDataframe

# Get the average user rating for the movies
avgUserRatingsResultset = dbSendQuery(mySQLConnection, 'SELECT mov.movie_name "Movie Name", CAST(AVG(ra.rating) AS DECIMAL(4,1)) "Average User Rating" FROM movies mov, ratings ra WHERE mov.movie_name = ra.movie_name GROUP BY mov.movie_name ORDER BY mov.movie_name')

# Reads the results as Dataframe
avgUserRatingsResultsAsDataframe = fetch(avgUserRatingsResultset, n=-1)

# Display the query results
avgUserRatingsResultsAsDataframe

# Disconnect the DB connection
dbDisconnect(mySQLConnection)

