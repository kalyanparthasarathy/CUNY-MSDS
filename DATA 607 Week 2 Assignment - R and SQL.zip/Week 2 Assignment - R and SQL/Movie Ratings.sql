
-- Create User for the MySQL DB
CREATE USER 'ruser'@'localhost' IDENTIFIED BY 'WelcomeUser1981';

-- Drop Schema if exists
DROP SCHEMA IF EXISTS entertainment;

-- Create Schema
CREATE SCHEMA entertainment;

-- Assign access to the schema/db
GRANT ALL PRIVILEGES ON *.* TO 'ruser' @'localhost' WITH GRANT OPTION;

-- Set the default schema,
USE entertainment;

-- Drop the table if it exists already
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS ratings;

-- Create the table to store movie details
CREATE TABLE movies (
	movie_name varchar(100),
	release_date date,
	running_time integer,
	genre varchar(50),
	director varchar(100)
)
;

-- Create the table to store ratings
CREATE TABLE ratings(
	movie_name varchar(100),
    person_rated varchar(50),
	rating integer
)
;

-- Load Movies data
LOAD DATA LOCAL INFILE '/Users/vidyakalyan/Data/Movies.csv' 
INTO TABLE movies
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
;

-- Load User Ratings data
LOAD DATA LOCAL INFILE '/Users/vidyakalyan/Data/Ratings.csv' 
INTO TABLE ratings
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
;


SELECT mov.movie_name "Movie Name", AVG(ra.rating) "Average User Rating" 
FROM movies mov, ratings ra 
WHERE mov.movie_name = ra.movie_name 
GROUP BY mov.movie_name 
ORDER BY mov.movie_name
;

